$(function () {


    //HEADER
    $(window).scroll(function () {
          if($(this).scrollTop() > 200)
          {
              if (!$('.main_header').hasClass('fixed'))
              {
                  $('.main_header').stop().addClass('fixed').css('top', '-100px').animate(
                      {
                          'top': '0px'
                      }, 500);
              }
          }
          else
          {
              $('.main_header').removeClass('fixed');
          }
    });

});

$(document).ready(function(){
    $('#toggle').click(function () {

        if (!$(this).hasClass('ativo')) {
            $(this).addClass('ativo');
            $('#menu').fadeIn(300);
        } else {
            $(this).removeClass('ativo');
            $('#menu').fadeOut(300);
        }
    });
});